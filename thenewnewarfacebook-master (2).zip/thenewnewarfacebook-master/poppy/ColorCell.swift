//
//  ColorCell.swift
//  poppy
//
//  Created by Jessica Joseph on 4/9/18.
//  Copyright © 2018 B0RN BKLYN. All rights reserved.
//

import UIKit

class ColorCell: UICollectionViewCell {
    @IBOutlet weak var colorButton:UIButton!
}
